#include <stdio.h>
int faku(int zahl);

int main(void){
   printf("Programm zur Berechnung von Fakultaeten \nBitte gebe die(Ganz-)Zahl ein von der du die Fakultaet errechenen m�chtest.\n");
   int zahl;
   scanf("%d", &zahl);
   fflush(stdin);
   printf("Die Fakultaet zu %d ist %d\n.",zahl, faku(zahl));
   
   return 0;
}

int faku(int zahl){
   int faku=1;
   int i=0;
   int zahl2;

   if(zahl<0)
      zahl2=zahl*-1;
   else
      zahl2=zahl;

   while(i<zahl2){
      i++;
      faku*=i;
   }
   if(zahl<0){
      faku*=-1;}
   else{}

   
   return faku;
}

