//Simulation der Zugbeschreibung fuer die "Tuerme von Hanoi"
#include <stdio.h>
#include <unistd.h>

#define ANZAHL_SCHEIBEN 5

void bewegen (int scheiben, int stabA, int stabB, int stabC, int maxScheiben);
void obersteScheibeVon_stabA_nach_stabC(int a, int b, int nMax);

//Spiefeld mit 3 Staeben und Max. 64 Scheiben
int  feld[3][64];

//Anzahl gespielter zuege
int zuege=0; 


int main (void){
   int a,b,c; //Die drei Staebe
   a=0;
   b=1;
   c=2;
   int n=0;

   // Startaufbau des Spielfelds (position der Scheiben)
   while(n<ANZAHL_SCHEIBEN){
      feld[0][n]=ANZAHL_SCHEIBEN-n;
      feld[1][n]=0;
      feld[2][n]=0;

      printf("feld 0, %d hat den Wert %d \n", n, ANZAHL_SCHEIBEN-n);//moegliche kontrolle der Position 
      n++;
   }

   n=1;//wiederverwendug von n zur Ausgabe der StartPosition der Spielsteine
   while(n<=ANZAHL_SCHEIBEN){
      printf("%d    %d    %d \n",feld[0][ANZAHL_SCHEIBEN-n],feld[1][ANZAHL_SCHEIBEN-n], feld[2][ANZAHL_SCHEIBEN-n]);

      n++;
   }
   printf("A    B    C\n**************************\n");

   //Start der eigentlichen Simulation
   bewegen(ANZAHL_SCHEIBEN,a,b,c,ANZAHL_SCHEIBEN);

   //Ausgabe wie viele Bewgungen (zuege) gebraucht wurden
   printf("\n------Es wurden %d Zuege gebraucht.------\n",zuege);

}


void bewegen(int scheiben, int stabA, int stabB, int stabC, int maxScheiben){
   if(scheiben>0){
      //1. Rekursiver Aufruf
      bewegen(scheiben-1, stabA, stabC, stabB, maxScheiben);

      //Eigentliche Positionsaenderung
      obersteScheibeVon_stabA_nach_stabC(stabA, stabC, maxScheiben);

      //2. Rekursiver Aufruf 
      bewegen(scheiben-1, stabB, stabA, stabC, maxScheiben);
   }
}


void obersteScheibeVon_stabA_nach_stabC(int a, int b, int nMax){
   //Hilfsvariable
   int i=1;

   //Berechnung aus welcher hoehe von stabA geholt werden soll
   while(feld[a][nMax-i]==0){
      i++;
   }

   //speicherung der Hoehe
   int holHohe=nMax-i;

   //speicherung des wertes der Scheibe
   int scheibenwert=feld[a][nMax-i];

   //wiederverwertung der Variable i
   i=nMax;

   //Berechnung der Zielhoehe
   while(feld[b][nMax-i]!=0){
      i--;
   }

   //Speicherung der Zielhoehe
   int zielHohe=nMax-i;

   //Neu Positionierung 
   feld[b][zielHohe]=scheibenwert;
   feld[a][holHohe]=0;

   //Zug abgeschlossen zuege++
   zuege++;;



   //wiederverwertung der Variable
   i=1;

   sleep(3);

   //Ausgabe (Visualisierung) f�r den User
   while(i<=nMax){
      printf("%d    %d   %d \n",feld[0][nMax-i], feld[1][nMax-i], feld[2][nMax-i]);
      i++;
   }
   printf("A    B    C\n**************************\n");
}

