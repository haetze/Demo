#include <stdio.h>
int main(void){
   int i,j;

   i=5;
   j=i;
   j=j;
   printf("i=%d \n",i);
   printf("j=%d \n",j);
   return 0;
}
