#include <stdio.h>
int tabelle[6][5];
int blacklist[4];
int list[5];


void textInstroction();
void insertCode();
void CodeTest();
void insertTry();
void tryTest();
void valuedTry(int);
void tabelleCreate();
int  blackListTest(int);
void tabelleUp(int);
void tabelleRight(int, int);
void listeValued(int);
void blacklistAdd(int);
void rules();

void rules(){
}



int main(void){
   textInstroction();
   insertCode();
   insertTry();
   tryTest();
   printf("wieder im main\n");
   tabelleCreate();
   valuedTry(1);
   return 0;
}


void textInstroction(){
   printf("Welcome to MasterMind! \n Rules <1> \n Play <2>\n");
   int ch=0;
   scanf("%d", &ch);
   if(ch==1){
      rules();
   }else{
   }
}

void insertCode(){
   printf("Coder, please enter the code. (Number by Number)");
   int i=1;
   int help;
   while(i<5){
      scanf("%d",&help);
      tabelle[0][i]=help;
      i++;
   }
   CodeTest();
}

void CodeTest(){
   int i=1;
   int test=0;
   while(i<5){
      if(tabelle[0][i]>7 || tabelle[0][i]<1){
         test=1;
         
      }
      i++;
   }
   if(test==1){
      printf("Something, you did, was Worng!! Read the instroctions carefully!!! ");
      insertCode();
   }
}

void insertTry(){
   printf("Asker, please enter the code. (Number by Number)");
   int i=1;
   int help;
   while(i<5){
      scanf("%d",&help);
      tabelle[i][0]=help;
      i++;
   }
  
}

void tryTest(){
   printf("TRyTest\n");
   int i=1;
   int test=0;
   while(i<5){
      if(tabelle[i][0]>7 || tabelle[i][0]<1){
         test=1;

      }
      i++;
   }
   printf("TRyTest nach while\n");
   if(test==1){
      printf("TRyTest im if\n");
      printf("Something, you did, was Worng!! Read the instroctions carefully!!! ");
      insertTry();
   }else{
      printf("TRyTest im else\n");
   }
   printf("TRyTest Ende\n");
}

void valuedTry(int number){
   printf("valuedTry\n");
   int bl= blackListTest(number);
   if(bl==1){
      tabelleUp(number);
      listeValued(number);
      blacklistAdd(number);
   }
   number++;
   if(number<5){
}
}
void tabelleCreate(){
   printf("tabelleCreate\n");
   int i=1;
   while(i<5){
      if(tabelle[i][0]==tabelle[0][1])
         tabelle[i][1]=1;
      if(tabelle[i][0]==tabelle[0][2])
         tabelle[i][2]=1;
      if(tabelle[i][0]==tabelle[0][3])
         tabelle[i][3]=1;
      if(tabelle[i][0]==tabelle[0][4])
         tabelle[i][4]=1;
      i++;
   }
   printf("tabelleCreate Ende\n");
}

int blackListTest(int wert){
   printf("blackListTest\n");
   int ente=0;
   while(ente<4){
      printf("In der while schleife\n");
      if(blacklist[ente]==tabelle[0][wert]){
         return 0;
      }
      ente++;
      printf("nach der if >schleife<\n");
   }
   return 1;
}

void tabelleUp(int spalte){
     printf("Tabelleup\n"); 
   int i=1;
   while(i<5){
      if(tabelle[spalte][i]==1){
         tabelleRight(spalte, i);
      }
      i++;
   }
}

void tabelleRight(int spalte, int zeile){
   while(spalte<5){
      if(tabelle[spalte][zeile]==1){
         list[spalte]=spalte;
         printf("%d\n", list[spalte]);

      }
      spalte++;
   }
}
void listeValued(int spalte) {
      printf("listevalued\n");
   while(spalte<5){
      int i=1;
      while(i<5){
         if(list[spalte]==tabelle[0][i]){
            if(spalte==i){
               tabelle[5][spalte]=2;
            }else{
               tabelle[5][spalte]=1;
            }
           
         }
         i++;
      }
      spalte++;
   }
}

void blacklistAdd(int spalte){
      printf("blackListadd\n");
   blacklist[spalte]=tabelle[spalte][0];
   int i =1;
   while(i<5){
      printf("%d\n", tabelle[5][i]);
      i++;
   }

   }

